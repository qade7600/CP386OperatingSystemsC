/*
 DScheduler.c

 Student Name : Rana Qaderi
 Student ID # : 170317600

 */

#include <string.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#include "dscheduler.h"

/*
 Any required standard libraries and your header files here
 */

struct schedulerInput loadRequest() {
	struct schedulerInput results;
	int numRequests;
	char line_buffer[MAX_LINE_LENGTH];
	char direction;
	char *token;

	//Process simulation input line by line
	fgets(line_buffer, MAX_LINE_LENGTH, stdin);

	token = strtok(line_buffer, " ");
	sscanf(token, "%d", &numRequests);

	token = strtok(NULL, " ");
	sscanf(token, "%d", &results.startTrack);

	token = strtok(NULL, " ");
	sscanf(token, "%c", &direction);
	results.direction = direction == 'u' ? 1 : -1;

	results.requests.elements = numRequests;
	results.requests.data = (int*) malloc(sizeof(int) * numRequests);
	if (results.requests.data == NULL) {
		fprintf( stderr, "Was unable to allocate space for requests data.\n");
		exit( BAD_MALLOC);
	}

	for (int i = 0; i < numRequests; i++) {
		token = strtok(NULL, " ");
		sscanf(token, "%d", &results.requests.data[i]);
	}

	return results;
}

void printResults(struct schedulerResult results) {
	for (int i = 0; i < results.requests.elements; i++) {
		printf("%4d", results.requests.data[i]);
	}
	printf(" Total Head Movement %5d\n", results.totalHeadMovement);
}

struct schedulerResult processRequest(enum POLICIES policy,
		struct schedulerInput request) {
	struct schedulerResult results;
	results.totalHeadMovement = 0;
	results.requests.data = NULL;
	results.requests.elements = 0;

	switch (policy) {
	case FCFS:
		return process_FCFS_request(request);
	case SSTF:
		return process_SSTF_request(request);
	case SCAN:
		return process_SCAN_request(request);
	case C_SCAN:
		return process_C_SCAN_request(request);
	}
	return results;
}

/* Fill in the following functions */
struct schedulerResult process_FCFS_request(struct schedulerInput request) {
	struct schedulerResult results;

	//make results equal requests so it prints in other function
	results.requests.elements = request.requests.elements;
	results.requests.data = (int*) malloc(
			sizeof(int) * request.requests.elements);

	//unnecessary but just to be sure do this
	results.totalHeadMovement = 0;

	//initialize variables we will be using
	int counter = 0;
	int total = 0;

	//subtract head from first element
	results.requests.data[0] = request.requests.data[0];
	total = abs(request.startTrack - request.requests.data[0]);
	results.totalHeadMovement += total;

	//start calculating totalHeadMovement
	for (int a = 1; a < request.requests.elements; a++) {
		//make elements in request equal to elements in result
		results.requests.data[a] = request.requests.data[a];
		//find absulte difference and add it to totalHeadMovement
		total = abs(request.requests.data[counter] - request.requests.data[a]);
		counter++;
		results.totalHeadMovement += total;
	}
	printf("FCFS ->");
	return results;
}

struct schedulerResult process_SSTF_request(struct schedulerInput request) {
	struct schedulerResult results;

	//make results equal requests so it prints in other function
	results.requests.elements = request.requests.elements;
	results.requests.data = (int*) malloc(
			sizeof(int) * request.requests.elements);

	//unnecessary but just to be sure do this
	results.totalHeadMovement = 0;

	//initialize variables
	int current = request.startTrack;
	int diff, minDiff, tracker;
	int el = request.requests.elements;

	//start loop to put things in SSTF order
	for (int a = 0; a < request.requests.elements; a++) {
		diff = 0, minDiff = 1023, tracker = 0;

		//find the closest next one
		for (int b = 0; b < el; b++) {
			diff = abs(current - request.requests.data[b]);
			if (minDiff > diff) {
				minDiff = diff;
				tracker = b;
			}
		}
		results.totalHeadMovement += minDiff;

		current = request.requests.data[tracker];
		results.requests.data[a] = current;

		//get rid of element that we added to results
		el--;
		for (int b = 0; b < el; b++) {
			if (b >= tracker) {
				request.requests.data[b] = request.requests.data[b + 1];
			}
		}

	}

	printf("SSTF ->");
	return results;
}

struct schedulerResult process_SCAN_request(struct schedulerInput request) {
	struct schedulerResult results;

	//make results equal requests so it prints in other function
	results.requests.elements = request.requests.elements;
	results.requests.data = (int*) malloc(
			sizeof(int) * request.requests.elements);

	//unnecessary but just to be sure do this
	results.totalHeadMovement = 0;

	//initialize variables
	int current = request.startTrack;
	int diff, minDiff, tracker, reached = 0, end = 1023;
	int el = request.requests.elements;

	//if direction is up
	if (request.direction == 1) {
		for (int a = 0; a < request.requests.elements; a++) {
			diff = 0, minDiff = 0, tracker = 0;
			//while still going up & haven't reached max yet
			if (reached == 0) {
				//go through all elements left in given array
				for (int b = 0; b < el; b++) {
					diff = current - request.requests.data[b]; // calculate difference
					//see if element is bigger
					if (diff < minDiff) {
						minDiff = diff; //update what is gonna be next
						tracker = b; //track what we need to delete
					}
				}
				if (minDiff != 0) {
					current = request.requests.data[tracker]; //change current
					results.requests.data[a] = current; // add current to new array
					results.totalHeadMovement += abs(minDiff); //add difference to totalHeadMovement
				} else if (minDiff == 0) {
					results.totalHeadMovement += abs(current - end);
					current = end; //make current 1023/the end
					reached = 1; //start moving down
				}
			}
			if (reached == 1) {
				diff = 0, minDiff = 1023, tracker = 0;
				//go through elements left in given array
				for (int c = 0; c < el; c++) {
					diff = abs(current - request.requests.data[c]); // calculate difference
					//see if element is smaller
					if (diff < minDiff) {
						minDiff = diff; //update what is gonna be next
						tracker = c; //track what we need to delete
					}
				}
				current = request.requests.data[tracker]; //change current
				results.requests.data[a] = current; //add current to new array
				results.totalHeadMovement += minDiff; //add difference to totalHeadMovement
			}
			//get rid of element that we added to results
			el--;
			for (int b = 0; b < el; b++) {
				if (b >= tracker) {
					request.requests.data[b] = request.requests.data[b + 1];
				}
			}
		}
		//if direction is down
	} else if (request.direction != 1) {
		for (int a = 0; a < request.requests.elements; a++) {
			diff = 0, minDiff = 1023, tracker = 0;
			//while still going down
			if (reached == 0) {
				//go through elements left in given array
				for (int b = 0; b < el; b++) {
					diff = current - request.requests.data[b]; // calculate difference
					//make sure we're still going down and element is smaller
					if (diff > 0 && diff < minDiff) {
						minDiff = diff; //update what is gonna be next
						tracker = b; //track what we need to delete
					}
				}
				if (minDiff == 1023) {
					results.totalHeadMovement += current;
					current = 0; //make current 0/the beginning
					reached = 1; // start going up
				} else {
					current = request.requests.data[tracker]; //change current
					results.requests.data[a] = current; //add current to array
					results.totalHeadMovement += abs(minDiff); //add difference to total array
				}
			}
			if (reached == 1) {
				diff = 0, minDiff = 0, tracker = 0;
				//go through elements left in array
				for (int c = 0; c < el; c++) {
					diff = current - request.requests.data[c]; //calculate difference
					//see if element is closer to current
					if (minDiff > diff) {
						minDiff = diff; //update what is gonna be next
						tracker = c; //track what we need to delete
					}
				}
				current = request.requests.data[tracker]; //change current
				results.requests.data[a] = current; //add current to array
				results.totalHeadMovement += abs(minDiff); //add difference to total array
			}

			//get rid of element that we added to results
			el--;
			for (int b = 0; b < el; b++) {
				if (b >= tracker) {
					request.requests.data[b] = request.requests.data[b + 1];
				}
			}
		}
	}

	printf("SCAN ->");
	return results;
}

struct schedulerResult process_C_SCAN_request(struct schedulerInput request) {
	struct schedulerResult results;

	//make results equal requests so it prints in other function
	results.requests.elements = request.requests.elements;
	results.requests.data = (int*) malloc(
			sizeof(int) * request.requests.elements);

	//unnecessary but just to be sure do this
	results.totalHeadMovement = 0;

	//initialize variables
	int current = request.startTrack;
	int diff, minDiff, tracker, reached = 0, end = 1023;
	int el = request.requests.elements;

	for (int a = 0; a < request.requests.elements; a++) {
		diff = 0, minDiff = 0, tracker = 0;
		//while still going up & haven't reached max yet
		if (reached == 0 && request.direction == 1) {
			//go through all elements left in given array
			for (int b = 0; b < el; b++) {
				diff = current - request.requests.data[b]; // calculate difference
				//see if element is bigger
				if (diff < minDiff) {
					minDiff = diff; //update what is gonna be next
					tracker = b; //track what we need to delete
				}
			}
			if (minDiff != 0) {
				current = request.requests.data[tracker]; //change current
				results.requests.data[a] = current; // add current to new array
				results.totalHeadMovement += abs(minDiff); //add difference to totalHeadMovement
			} else if (minDiff == 0) {
				results.totalHeadMovement += abs(current - end);
				results.totalHeadMovement += end;
				current = 0; //make current 1023/the end
				reached = 1; //start moving down
			}
		}
		if(request.direction != 1 && reached == 0) {
			results.totalHeadMovement += current;
			current = 0;
			reached = 1;
		}
		if (reached == 1) {
			diff = 0, minDiff = 1023, tracker = 0;
			//go through elements left in given array
			for (int c = 0; c < el; c++) {
				diff = abs(current - request.requests.data[c]); // calculate difference
				//see if element is smaller
				if (diff < minDiff) {
					minDiff = diff; //update what is gonna be next
					tracker = c; //track what we need to delete
				}
			}
			current = request.requests.data[tracker]; //change current
			results.requests.data[a] = current; //add current to new array
			results.totalHeadMovement += minDiff; //add difference to totalHeadMovement
		}
		//get rid of element that we added to results
		el--;
		for (int b = 0; b < el; b++) {
			if (b >= tracker) {
				request.requests.data[b] = request.requests.data[b + 1];
			}
		}
	}

	printf("C-SCAN ->");

	return results;
}

